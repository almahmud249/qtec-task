<?php $__env->startSection('content'); ?>
    <div style="height: 100vh;" class="body_wraper p-md-5 p-3 ">
        <div>
            <div class="login_box cm_box row">
                <?php $__currentLoopData = $fields->form_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="common_input mb-5 col-md-3">
                        <label><?php echo e($field['label']); ?></label>
                        <?php if($field['type'] == 'radio'): ?>
                                <input class="nn_input" name="seller_pos" type="<?php echo e($field['type']); ?>" value="1" id="seller_pos1">
                                <label class="title-color mb-0" for="seller_pos1">
                                    Male
                                </label>
                                <input class="nn_input" name="seller_pos" type="<?php echo e($field['type']); ?>" value="0" id="seller_pos2" checked="">
                                <label class="title-color mb-0" for="seller_pos2">
                                    Female
                                </label>
                        <?php elseif($field['type'] == 'checkbox'): ?>
                            <input class="nn_input" name="seller_pos" type="<?php echo e($field['type']); ?>" value="1" id="seller_pos1">
                            <label class="title-color mb-0" for="seller_pos1">
                                HTML
                            </label>
                            <input class="nn_input" name="seller_pos" type="<?php echo e($field['type']); ?>" value="0" id="seller_pos2" checked="">
                            <label class="title-color mb-0" for="seller_pos2">
                                CSS
                            </label>
                            <input class="nn_input" name="seller_pos" type="<?php echo e($field['type']); ?>" value="0" id="seller_pos2" checked="">
                            <label class="title-color mb-0" for="seller_pos2">
                                JavaScript
                            </label>
                        <?php else: ?>
                            <input class="nn_input"
                                   placeholder="Enter <?php echo e($field['label']); ?>"
                                   type="<?php echo e($field['type']); ?>">
                        <?php endif; ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\New folder\qtec-task\resources\views/admin/form/view-form.blade.php ENDPATH**/ ?>